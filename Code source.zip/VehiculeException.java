package NewTp;

public class VehiculeException extends Exception {

  public VehiculeException( String m) {
    super(m);
  }
}