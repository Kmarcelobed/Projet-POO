package NewTp;

public interface Louable {
    void loue () throws VehiculeException;
    void retourner();
}
